#ifndef _RADIXSORT_H_
#define _RADIXSORT_H_

#include <iostream>

void radixsort(unsigned int* srcarr,int num,int r);

#endif //_RADIXSORT_H_