#ifndef _MERGESORT_H_
#define _MERGESORT_H_

#include <iostream>

void mergesort(unsigned int* srcarr,int lb,int rb,int stoppoint);

#endif //_MERGESORT_H_