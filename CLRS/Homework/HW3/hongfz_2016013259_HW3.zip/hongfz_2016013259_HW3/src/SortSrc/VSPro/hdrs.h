#ifndef _HDRS_H_
#define _HDRS_H_

#include <iostream>
#include <ctime>
#include <string>
#include "insertionsort.h"
#include "mergesort.h"
#include "quicksort.h"
#include "radixsort.h"
#include "shellsort.h"
#include "32UIntRand.h"

#endif //_HDRS_H_