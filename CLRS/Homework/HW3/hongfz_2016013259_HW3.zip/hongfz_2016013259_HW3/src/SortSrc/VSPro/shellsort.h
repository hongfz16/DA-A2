#ifndef _SHELLSORT_H_
#define _SHELLSORT_H_

#include <iostream>

int getshelldelta(int** delta,int n);
void shellsort(unsigned int* srcarr,int num,int* delta,int deltanum);

#endif