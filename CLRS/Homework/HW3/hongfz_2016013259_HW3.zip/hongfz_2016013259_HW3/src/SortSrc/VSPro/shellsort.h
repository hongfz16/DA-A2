#ifndef _SHELLSORT_H_
#define _SHELLSORT_H_

#include <iostream>

void shellsort(unsigned int* srcarr,int num,int* delta,int deltanum);

#endif