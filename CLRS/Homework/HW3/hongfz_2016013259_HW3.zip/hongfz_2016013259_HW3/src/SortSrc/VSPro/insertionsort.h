#ifndef _INSERTIONSORT_H_
#define _INSERTIONSORT_H_

#include <iostream>

void insertionsort(unsigned int* srcarr,int num);

#endif //_INSERTIONSORT_H_