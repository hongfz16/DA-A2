#ifndef _32UINTRAND_H_
#define _32UINTRAND_H_

#include <iostream>
#include <ctime>
#include <cstdlib>

unsigned int UInt32Rand();

#endif //_32UINTRAND_H_