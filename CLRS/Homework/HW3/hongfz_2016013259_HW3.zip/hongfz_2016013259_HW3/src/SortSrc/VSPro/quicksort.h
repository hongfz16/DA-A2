#ifndef _QUICKSORT_H_
#define _QUICKSORT_H_

#include <iostream>

void quicksort(unsigned int* srcarr,int lb,int rb,int stoppoint);

#endif //_QUICKSORT_H_